import { motion } from "motion/react";
import { Button } from "./ui/button";
import { ArrowRight, FileText, Award, ShieldCheck, ExternalLink } from "lucide-react";
import { Link } from "react-router";
import { useLanguage } from "../context/language-context";
import { Product } from "../data/products";

interface ProductCardProps {
  product: Product;
  index: number;
}

export function ProductCard({ product, index }: ProductCardProps) {
  const { t } = useLanguage();

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="group bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden hover:shadow-2xl transition-all duration-300"
    >
      <div className="grid md:grid-cols-2 gap-6 p-6">
        {/* Product Image */}
        <div className="relative rounded-xl overflow-hidden bg-gradient-to-br from-red-50 to-gray-50 flex items-center justify-center p-8">
          <img
            src={product.image}
            alt={t(product.nameKey)}
            className="w-full h-64 object-cover rounded-lg group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute top-4 right-4">
            <div className="px-3 py-1 rounded-full bg-red-500 text-white text-sm font-medium">
              {product.category}
            </div>
          </div>
        </div>

        {/* Product Details */}
        <div className="flex flex-col justify-between">
          <div className="space-y-4">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">
                {t(product.nameKey)}
              </h3>
              <p className="text-gray-600">
                {t(product.descKey)}
              </p>
            </div>

            {/* Action Links */}
            <div className="space-y-2">
              <a
                href="#"
                className="flex items-center gap-2 text-sm text-red-500 hover:text-red-600 transition-colors"
              >
                <ExternalLink className="w-4 h-4" />
                <span className="font-medium">{t("products.buyOnline")}</span>
              </a>
              <a
                href="#"
                className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900 transition-colors"
              >
                <FileText className="w-4 h-4" />
                <span>{t("products.technicalSheet")}</span>
              </a>
              <a
                href="#"
                className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900 transition-colors"
              >
                <Award className="w-4 h-4" />
                <span>{t("products.certificates")}</span>
              </a>
              <a
                href="#"
                className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900 transition-colors"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>{t("products.safetySheet")}</span>
              </a>
            </div>
          </div>

          <div className="mt-6">
            <Button
              asChild
              className="w-full bg-red-500 hover:bg-red-600 group"
            >
              <Link to={`/products/${product.id}`}>
                {t("products.viewDetails")}
                <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
